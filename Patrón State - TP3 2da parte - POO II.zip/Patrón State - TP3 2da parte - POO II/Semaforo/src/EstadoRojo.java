/**
 * La clase EstadoRojo representa el estado rojo de un semáforo en el sistema de control de tráfico.
 * En este estado, los vehículos deben detenerse.
 */
public class EstadoRojo implements EstadoSemaforo {

    /**
     * Cambia el estado del semáforo a amarillo cuando se invoca este método.
     *
     * @param semaforo el semáforo que cambiará su estado.
     */
    @Override
    public void cambiar(Semaforo semaforo) {
        semaforo.setEstadoActual(new EstadoAmarillo());
    }

    /**
     * Muestra la acción correspondiente al estado rojo del semáforo.
     * Indica que los vehículos deben detenerse.
     */
    @Override
    public void mostrarAccion() {
        System.out.println("El semaforo está en Rojo, los vehiculos proceden a Detenerse");
    }
}
