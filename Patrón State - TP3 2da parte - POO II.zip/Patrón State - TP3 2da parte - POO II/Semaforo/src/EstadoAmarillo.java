/**
 * La clase EstadoAmarillo representa el estado amarillo de un semáforo en el sistema de control de tráfico.
 * En este estado, los vehículos deben reducir la velocidad.
 */
public class EstadoAmarillo implements EstadoSemaforo {

    /**
     * Cambia el estado del semáforo dependiendo del estado previo.
     * Si el estado previo es rojo, cambia a verde. Si el estado previo es verde, cambia a rojo.
     *
     * @param semaforo el semáforo que cambiará su estado.
     */
    @Override
    public void cambiar(Semaforo semaforo) {
        if (semaforo.getEstadoPrevio() instanceof EstadoRojo) {
            semaforo.setEstadoActual(new EstadoVerde());
        } else if (semaforo.getEstadoPrevio() instanceof EstadoVerde) {
            semaforo.setEstadoActual(new EstadoRojo());
        }
    }

    /**
     * Muestra la acción correspondiente al estado amarillo del semáforo.
     * Indica que los vehículos deben bajar la velocidad.
     */
    @Override
    public void mostrarAccion() {
        System.out.println("El semaforo está en Amarillo, los vehículos proceden a Bajar la Velocidad");
    }
}
