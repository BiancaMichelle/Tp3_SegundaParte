/**
 * La interfaz EstadoSemaforo define el comportamiento de los estados de un semáforo.
 * Cada estado debe implementar la lógica para cambiar el estado del semáforo
 * y mostrar la acción correspondiente a ese estado.
 */
public interface EstadoSemaforo {

    /**
     * Cambia el estado del semáforo según la lógica del estado actual.
     *
     * @param semaforo el semáforo cuyo estado se va a cambiar.
     */
    void cambiar(Semaforo semaforo);

    /**
     * Muestra la acción correspondiente al estado del semáforo.
     */
    void mostrarAccion();
}
