/**
 * La clase App contiene el método principal que inicia la aplicación.
 * En este contexto, se simula el comportamiento de un semáforo que cambia de estado.
 */
public class App {
    /**
     * El método principal de la aplicación.
     * Crea una instancia de Semaforo y simula el cambio de estados de este semáforo en un bucle.
     *
     * @param args argumentos de la línea de comandos (no se utilizan en este caso).
     * @throws Exception en caso de que ocurra un error durante la ejecución.
     */
    public static void main(String[] args) throws Exception {
        
        Semaforo semaforo = new Semaforo();

        // Simula el cambio de estado del semáforo 6 veces.
        for (int i = 0; i < 6; i++) { 
            System.out.println("Estado actual:");
            semaforo.mostrarAccionActual();  
            semaforo.cambiarEstado();        
        }
    }
}
