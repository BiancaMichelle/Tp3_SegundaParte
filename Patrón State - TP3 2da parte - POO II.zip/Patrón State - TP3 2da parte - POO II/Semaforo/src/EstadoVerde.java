/**
 * La clase EstadoVerde representa el estado verde de un semáforo en el sistema de control de tráfico.
 * En este estado, los vehículos pueden avanzar.
 */
public class EstadoVerde implements EstadoSemaforo {

    /**
     * Cambia el estado del semáforo a amarillo cuando se invoca este método.
     *
     * @param semaforo el semáforo que cambiará su estado.
     */
    @Override
    public void cambiar(Semaforo semaforo) {
        semaforo.setEstadoActual(new EstadoAmarillo());
    }

    /**
     * Muestra la acción correspondiente al estado verde del semáforo.
     * Indica que los vehículos pueden avanzar.
     */
    @Override
    public void mostrarAccion() {
        System.out.println("El semaforo está en Verde, los vehiculos proceden a Avanzar");
    }
}
