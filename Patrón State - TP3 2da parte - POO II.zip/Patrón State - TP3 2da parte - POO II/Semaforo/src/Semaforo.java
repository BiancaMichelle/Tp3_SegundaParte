import java.util.UUID;

/**
 * La clase Semaforo representa un semáforo en un sistema de control de tráfico.
 * Un semáforo puede tener diferentes estados (Rojo, Amarillo, Verde) y
 * puede cambiar entre estos estados de acuerdo a su lógica interna.
 */
public class Semaforo {

    /**
     * Identificador único del semáforo.
     */
    private String idSemaforo = String.valueOf(UUID.randomUUID());
    
    /**
     * Estado actual del semáforo.
     */
    private EstadoSemaforo estadoActual;

    /**
     * Estado previo del semáforo, utilizado para transiciones de estado.
     */
    private EstadoSemaforo estadoPrevio;

    /**
     * Constructor que inicializa el semáforo en estado Rojo.
     */
    public Semaforo() {
        this.estadoActual = new EstadoRojo();
        this.estadoPrevio = null;
    }

    /**
     * Obtiene el identificador del semáforo.
     *
     * @return el identificador único del semáforo.
     */
    public String getIdSemaforo() {
        return idSemaforo;
    }

    /**
     * Obtiene el estado actual del semáforo.
     *
     * @return el estado actual del semáforo.
     */
    public EstadoSemaforo getEstadoActual() {
        return estadoActual;
    }

    /**
     * Obtiene el estado previo del semáforo.
     *
     * @return el estado previo del semáforo.
     */
    public EstadoSemaforo getEstadoPrevio() {
        return estadoPrevio;
    }

    /**
     * Establece un nuevo estado para el semáforo, actualizando el estado previo.
     *
     * @param nuevoEstado el nuevo estado a establecer.
     */
    public void setEstadoActual(EstadoSemaforo nuevoEstado) {
        this.estadoPrevio = this.estadoActual;
        this.estadoActual = nuevoEstado;
    }

    /**
     * Cambia el estado actual del semáforo de acuerdo a la lógica del estado actual.
     */
    public void cambiarEstado() {
        estadoActual.cambiar(this);
    }

    /**
     * Muestra la acción correspondiente al estado actual del semáforo.
     */
    public void mostrarAccionActual() {
        estadoActual.mostrarAccion();
    }
}
